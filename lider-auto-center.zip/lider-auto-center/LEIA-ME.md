# Líder Auto Center — código-fonte

- `frontend/` — site (React + Tailwind + framer-motion + lenis). Imagens em `frontend/public/img`.
- `backend/` — API (FastAPI + MongoDB) que guarda os pedidos do formulário de agendamento (`POST /api/agendamentos`).
- Contatos (WhatsApp, endereço, Instagram) ficam em `frontend/src/data/site.js`.

Os arquivos `.env` NÃO estão incluídos. Copie os `.env.example` para `.env` e preencha.

## Rodar no seu computador
Requisitos: Node 20 + Yarn 1, Python 3.11, MongoDB (local ou Atlas).

Backend:
```
cd backend
python -m venv venv && source venv/bin/activate   (Windows: venv\Scripts\activate)
pip install -r requirements.txt
cp .env.example .env    (edite MONGO_URL, DB_NAME, CORS_ORIGINS=*)
uvicorn server:app --reload --port 8001
```

Frontend:
```
cd frontend
cp .env.example .env    (REACT_APP_BACKEND_URL=http://localhost:8001)
yarn install
yarn start              (abre em http://localhost:3000)
```

## Publicar grátis

### Opção A — só o site (mais simples)
Netlify, Vercel ou Cloudflare Pages:
- Pasta base: `frontend`
- Comando de build: `yarn build`
- Pasta publicada: `frontend/build`
Sem backend, o site inteiro funciona; só o envio do formulário mostra um aviso pedindo para chamar no WhatsApp (todos os botões de WhatsApp funcionam).

### Opção B — site + agendamentos salvos
1. Banco: crie um cluster gratuito (M0) no MongoDB Atlas (mongodb.com/atlas), crie usuário/senha e libere acesso de rede (0.0.0.0/0). Copie a connection string.
2. Backend no Render (render.com) → New Web Service:
   - Root directory: `backend`
   - Build: `pip install -r requirements.txt`
   - Start: `uvicorn server:app --host 0.0.0.0 --port $PORT`
   - Variáveis: `MONGO_URL`, `DB_NAME`, `CORS_ORIGINS` (URL do seu site)
   - Teste: `https://SEU-BACKEND.onrender.com/api/` deve responder.
   - Obs.: no plano gratuito o Render "dorme" após inatividade; o primeiro envio pode demorar ~1 min.
3. Frontend na Netlify/Vercel como na Opção A, adicionando a variável `REACT_APP_BACKEND_URL=https://SEU-BACKEND.onrender.com` (sem barra no final) e refazendo o deploy.

## Observações
- `frontend/public/index.html` tem dois scripts da plataforma Emergent (emergent-main.js e posthog). Você pode removê-los com segurança fora da Emergent.
- Se `yarn install` falhar nos pacotes `@emergentbase/...` (devDependencies do `package.json`), remova essas duas linhas e as referências em `craco.config.js`/`plugins`.
